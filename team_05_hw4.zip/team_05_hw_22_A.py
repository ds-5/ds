
#22-A-1. Parenthesis Matching using Python
# Version-1. user define
'''
괄호 매칭에 성공한 경우는 리스트에 저장했다가 마지막에 출력,
스택이 없는 상태로 괄호 닫는 경우 발생하면 바로 empty 출력.
마지막에 스택이 남아있는 경우 괄호 열고 끝나는 경우이므로 no match 출력.
'''
class myStack():

    def __init__(self):
        self.stack = []

    def isEmpty(self):
        if self.stack:
            return False
        return True

    def push(self, x):
        self.stack.append(x)

    def pop(self):
        return self.stack.pop()

def printMatchedPairs_self(s):
    stack = myStack()
    result = []
    for i, c in enumerate(s):
        if c == '(':
            stack.push(i)
        elif c == ')':
            if stack.isEmpty():
                print('Stack was empty, no match exists')
            else:
                result.append('(%d,%d)' % (stack.pop(), i))
    print(', '.join(result))
    while not stack.isEmpty():
        print('No match for left parenthesis at', stack.pop())

# Version-2. import module
import queue
def printMatchedPairs_import(s):
    stack = queue.LifoQueue(len(s))
    result = []
    for i, c in enumerate(s):
        if c == '(':
            stack.put(i)
        elif c == ')':
            if stack.qsize():
                result.append('(%d,%d)' % (stack.get(), i))
            else:
                print('Stack was empty, no match exists')
    print(', '.join(result))
    while stack.qsize():
        print('No match for left parenthesis at', stack.get())

# TEST
'''
strings = ['(a*(b+c)+d)', '(a*(b+c+d)', '(a*b+c)+d)', '(a*(((b+c)+d)']
for s in strings:
    print('self:')
    printMatchedPairs_self(s)
    print('import:')
    printMatchedPairs_import(s)
    print()
'''

#22-A-2. Tower of Hanoi using Python
def towersOfHanoi(n, x, y, z):
    if n > 0:
        towersOfHanoi(n-1, x, z, y)
        y.append(x.pop())
        printTower(x0,y0,z0)
        towersOfHanoi(n-1, z, y, x)

def printTower(x,y,z):
    height = sum(map(len, [x,y,z]))-1
    for i in range(height,-1,-1):
        for l in [x,y,z]:
            if len(l) > i:
                print('[%d]   '%l[i], end='')
            else:
                print('      ',end='')
        print()
    print('-----------------')

#TEST
'''
x0 = list(range(3,0,-1))
y0 = []
z0 = []
printTower(x0,y0,z0)
towersOfHanoi(len(x0), x0, y0, z0)
'''