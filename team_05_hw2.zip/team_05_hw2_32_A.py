import numpy as np
import pandas as pd
import sklearn
import sklearn.neural_network as nn
import sklearn.svm as svm
import sklearn.linear_model as lm
import sklearn.neighbors as neighbors
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터 읽기
rawdata = pd.read_csv('32-Data-Data_Viz_Practice.csv.txt')
rawdata.head()

# 데이터 셋 탐색, Attribute 별 특징 및 통계치 확인.
rawdata.describe()

# null 값 확인
rawdata.isnull().sum()

# corr 정보 확인
df_corr = rawdata.corr()
df_corr.head()

# corr 영향 정도 확인.
ax = sns.heatmap(df_corr, vmin = -1, vmax = 1, cmap=sns.diverging_palette(20,220, n=10))
ax.set_xticklabels(ax.get_xticklabels())

# class0 과 1 로 구분했을 때, class1 정보가 작으므로 비정상으로 추정.
print('Class', rawdata.Class.describe())
print()
print('Class 0: ', rawdata[rawdata.Class ==0].Class.count())
print('Class 1: ', rawdata[rawdata.Class ==1].Class.count())

###class가 기준으로 시간 단위로 bar chart

f, (ax1, ax2) = plt.subplots(2,1, sharex = True, figsize =(12,4))

ax1.hist(rawdata.Time[rawdata.Class == 1], bins = 50)
ax1.set_title('Ones')

ax2.hist(rawdata.Time[rawdata.Class == 0], bins = 50)
ax2.set_title('Zeros')

plt.xlabel('Time')
plt.ylabel('Count')
plt.show()

### amount단위로

f, (ax1, ax2) = plt.subplots(2,1, sharex = True, figsize =(12,4))

ax1.hist(rawdata.Amount[rawdata.Class == 1], bins = 30)
ax1.set_title('Ones')

ax2.hist(rawdata.Amount[rawdata.Class == 0], bins = 30)
ax2.set_title('Zeros')

plt.xlabel('Amount')
plt.ylabel('Number')
plt.yscale('log')
plt.show()

f, (ax1, ax2) = plt.subplots(2,1, sharex = True, figsize =(12,6))

ax1.scatter(rawdata.Time[rawdata.Class == 1], rawdata.Amount[rawdata.Class == 1])
ax1.set_title('Ones')

ax2.scatter(rawdata.Time[rawdata.Class == 0], rawdata.Amount[rawdata.Class == 0], color = 'red')
ax2.set_title('Zeros')

plt.xlabel('Time')
plt.ylabel('Amount')
plt.show()

plt.scatter(rawdata.Time[rawdata.Class == 0], rawdata.Amount[rawdata.Class == 0], c = 'b')
plt.scatter(rawdata.Time[rawdata.Class == 1], rawdata.Amount[rawdata.Class == 1], c = 'r')
plt.xlabel('Time')
plt.ylabel('Amount')
plt.show()

v_features = rawdata.iloc[:, 1:29].columns
plt.figure(figsize = (12, 28*4))
aa = plt.GridSpec(29,1)
for i, cn in enumerate(rawdata[v_features]):
    ax = plt.subplot(aa[i])
    sns.distplot(rawdata[cn][rawdata.Class == 0], bins = 50, color = 'red')
    sns.distplot(rawdata[cn][rawdata.Class == 1], bins = 50, color = 'green')
    ax.set_title('histogram of feature: ' + str(cn))

plt.show()



# 추가 Plot 그리기.
# 클래스 간에 평균 값의 차이가 큰 attribute 를 기준으로 그래프를 그려보기
class_zero = rawdata[rawdata['Class']==0]
class_one = rawdata[rawdata['Class']==1]
class_zero.shape, class_one.shape

class_zero_values = class_zero.loc[:,'V1':'Amount']
class_one_values = class_one.loc[:,'V1':'Amount']

class_zero_values.loc[:3,:]

class_zero_values.loc[:3,:].mean()

# V1 ~ Amount 중, 평균값 및 분산의 차이(abs)가 큰 5개 attribute 를 정렬.
df_mean_diff = pd.DataFrame(abs(class_zero_values.mean() - class_one_values.mean())).sort_values([0], ascending=False)
df_mean_diff[:5]

df_var_diff = pd.DataFrame(abs(class_zero_values.var() - class_one_values.var())).sort_values([0], ascending=False)
df_var_diff[:5]

# 위에서 발견한 유의차 있는 attribute 를 plot.

for sub_no, attr in [(221, 'V3'),(222, 'V14'), (223, 'V17'), (224, 'V12')]:
    plt.subplot(sub_no)
    plt.plot(class_zero_values[attr],'go', class_one_values[attr],'rx')

for sub_no, attr in [(221, 'V7'),(222, 'V3'), (223, 'V17'), (224, 'V8')]:
    plt.subplot(sub_no)
    plt.plot(class_zero_values[attr],'go', class_one_values[attr],'rx')

# 위의 조합 중 (V8, V12) 가 1과 0의 영역 구별이 되어 보인다.
plt.scatter(class_zero_values['V8'], class_zero_values['V12'], s=5, c='g')
plt.scatter(class_one_values['V8'], class_one_values['V12'], s=5, c='r')
